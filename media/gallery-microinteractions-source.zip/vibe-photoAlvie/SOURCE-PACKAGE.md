# 源码包

包含交互网页、照片、字体、影片渲染与音频合成源码。

视频请从 https://jdb156158.github.io/vibe-photoAlvie/media/gallery-microinteractions-20s.mp4 单独下载，放到 media/ 文件夹。完整媒体文件也在 GitHub 仓库。

音轨由 film/make_audio.py 生成；影片检查截图可从仓库 film/previews/ 查看。
